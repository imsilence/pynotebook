#encoding: utf-8

import userspkg
from userspkg import users


print(users.path)
print(users.load_users(users.path))
