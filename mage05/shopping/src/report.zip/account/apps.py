from django.apps import AppConfig


class AccountConfig(AppConfig):
    name = 'account'
    verbose_name = '用户'
