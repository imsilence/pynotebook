#encoding: utf-8


from django.conf.urls import url

app_name = 'goods'

urlpatterns = [

]
