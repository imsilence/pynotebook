from django.shortcuts import render

from django.http import HttpResponse, HttpResponseRedirect

from . import models

# Create your views here.

def require_login(request):
    return render(request, 'user/login.html')


def login(request):

    username = request.POST.get('username', '')
    password = request.POST.get('password', '')
    print(username, password)
    rt = models.validate_login(username, password)
    if rt:
        #return HttpResponse('success')
        return HttpResponseRedirect('/user/list_user/')
    else:
        context = {'error' : '用户名或密码错误', 'username' : username, 'password' : password}
        return render(request, 'user/login.html', context)
        


def list_user(request):
    users = models.load_users(models.path) 
    users = list(users.values())
    return render(request, 'user/list.html', {'users' : users})


def delete_user(request):
    name = request.GET.get('name', '')
    print(name)
    models.delete_user(name)
    return HttpResponseRedirect('/user/list_user/')
