#encoding: utf-8

import users

print(users.path)
print(users.user_info_tpl)
print(users.load_users(users.path))
