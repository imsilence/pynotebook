from django.apps import AppConfig


class ReportConfig(AppConfig):
    name = 'report'
    verbose_name = '报表'